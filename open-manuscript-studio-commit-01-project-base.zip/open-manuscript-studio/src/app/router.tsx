import { createBrowserRouter } from 'react-router-dom';
import { Shell } from '../layout/Shell';

export const router = createBrowserRouter([
  {
    path: '/',
    element: <Shell />
  }
]);
