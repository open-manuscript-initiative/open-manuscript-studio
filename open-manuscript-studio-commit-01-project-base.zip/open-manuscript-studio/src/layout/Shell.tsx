import { Editor } from './Editor';
import { Inspector } from './Inspector';
import { Sidebar } from './Sidebar';

export function Shell() {
  return (
    <div className="app-shell">
      <header className="app-header">
        <div>
          <p className="eyebrow">Open Manuscript Initiative</p>
          <h1>Open Manuscript Studio</h1>
        </div>
        <div className="header-actions">
          <button type="button">New manuscript</button>
          <button type="button" className="secondary">
            Export .omi.json
          </button>
        </div>
      </header>

      <main className="workspace" aria-label="Open Manuscript Studio workspace">
        <Sidebar />
        <Editor />
        <Inspector />
      </main>
    </div>
  );
}
