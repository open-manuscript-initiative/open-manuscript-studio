const documentItems = [
  'Metadata',
  'Abstract',
  'Introduction',
  'Sections',
  'Figures',
  'Tables',
  'References',
  'Appendices'
];

export function Sidebar() {
  return (
    <aside className="panel sidebar" aria-label="Document structure">
      <h2>Document</h2>
      <nav>
        {documentItems.map((item) => (
          <button type="button" key={item}>
            {item}
          </button>
        ))}
      </nav>
    </aside>
  );
}
