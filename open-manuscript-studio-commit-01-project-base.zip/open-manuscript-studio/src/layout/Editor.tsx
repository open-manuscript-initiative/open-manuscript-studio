export function Editor() {
  return (
    <section className="panel editor" aria-label="Manuscript editor">
      <p className="eyebrow">Draft manuscript</p>
      <h2>Untitled OMI manuscript</h2>
      <div className="editor-surface" contentEditable suppressContentEditableWarning>
        <h3>Introduction</h3>
        <p>
          Start writing a structured scholarly manuscript. The editor shell is
          intentionally separated from the OMI document model so that exports can
          target JATS, DOCX, HTML, PDF, and other publication formats.
        </p>
      </div>
    </section>
  );
}
