const inspectorSections = ['Metadata', 'Annotations', 'Citations', 'Publisher profile', 'Export'];

export function Inspector() {
  return (
    <aside className="panel inspector" aria-label="Properties inspector">
      <h2>Properties</h2>
      {inspectorSections.map((section) => (
        <section className="inspector-card" key={section}>
          <h3>{section}</h3>
          <p>Alpha placeholder for {section.toLowerCase()}.</p>
        </section>
      ))}
    </aside>
  );
}
