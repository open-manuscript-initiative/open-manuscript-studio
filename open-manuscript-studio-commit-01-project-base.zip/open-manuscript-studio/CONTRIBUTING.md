# Contributing

Open Manuscript Studio is developed as a reference implementation of the Open Manuscript Initiative.

## Local workflow

1. Create a feature branch.
2. Keep changes small and focused.
3. Run `npm run typecheck` and `npm run build` before opening a pull request.
4. Document changes that affect the OMI document model.

## Commit style

Use concise commit messages, for example:

```text
feat: add document tree shell
fix: correct editor panel layout
chore: update CI workflow
```
