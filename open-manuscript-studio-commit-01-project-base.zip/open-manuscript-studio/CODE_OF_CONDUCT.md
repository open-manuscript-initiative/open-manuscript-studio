# Code of Conduct

Participants are expected to communicate respectfully and constructively.

The project welcomes scholarly, technical, editorial, and publishing expertise. Disagreements should focus on specifications, implementation details, evidence, and maintainability.
