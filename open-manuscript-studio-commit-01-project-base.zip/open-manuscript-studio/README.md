# Open Manuscript Studio

Reference implementation of the Open Manuscript Initiative Studio.

## Development

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

The production build is generated into the `dist/` directory. For `studio.openmanuscript.org`, upload the contents of `dist/` to the configured web root, currently `httpdocs/studio/`.

## Alpha 0.1 scope

- React + TypeScript + Vite project base
- Three-panel scholarly editor shell
- OMI document model foundation
- Native `.omi.json` import/export in later alpha commits
